package com.example.realestate.Model;

public class notification {
    private  String pid, address, image, price,phone, fullname, email;

    public notification(){

    }

    public notification(String pid, String address, String image, String price, String phone,String fullname, String email) {
        this.pid = pid;
        this.address = address;
        this.image = image;
        this.price = price;
        this.phone = phone;
        this.fullname = fullname;
        this.email = email;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
}
