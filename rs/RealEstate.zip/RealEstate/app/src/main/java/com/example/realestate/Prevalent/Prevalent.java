package com.example.realestate.Prevalent;

import com.example.realestate.Model.Users;

public class Prevalent {
    public static Users currentonlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
