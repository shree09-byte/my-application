package com.example.realestate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AdminNewOrdersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_new_orders);
    }
}